#include <cvirte.h>		
#include <userint.h>
#include <ansi_c.h>
#include "RecordTestMain.h"

#define DATARECORDSIZE 20 * 64
#define TOTALRECORDSIZE 1298
#define LOWNUMBERRECORDS 1
#define HINUMBERRECORDS 5000


static int panelHandle;
short RecordOne = 0;
short NumRecords = 0;
char FilePath[260];
int GotFile = 0;
int Switch =0;

char result_time[18];
char result_blocks[64][20];
int line_status;
unsigned long blkhdr_ticks;
float line_data, relativetime;
unsigned int uInitialSeed;
fpos_t DataStart;
char *DataPointer;
FILE *fp;

void SkipToRecord(int);
int GetRecord(int);

int main (int argc, char *argv[])
{
	
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "RecordTestMain.uir", PANEL)) < 0)
		return -1;
	srand (uInitialSeed);
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

int CVICALLBACK SelectFirstRecord (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			GetCtrlVal (PANEL, control, &RecordOne);
			if (RecordOne <=0){
				MessagePopup ("Error", "Starting Record Position Must be Greater than 0");
				return(0);
			}
		
			break;
	}
	return 0;
}

int CVICALLBACK GetNumberRecords (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	unsigned int uRecordOne;
	int RandomValue;
	
	switch (event)
	{
		case EVENT_COMMIT:
			uRecordOne = RecordOne;

			srand (uRecordOne);
			RandomValue = rand ();
			NumRecords = ((float)RandomValue/(float)RAND_MAX) *5000;
			uInitialSeed = RandomValue;

			if (NumRecords <=0){
				MessagePopup ("Error", "Number of Records Must be Greater than 0");
				return(0);
			}
			SetCtrlVal (panel, PANEL_NumberRecords, NumRecords);
			DataPointer = malloc (TOTALRECORDSIZE*NumRecords);
			
			break;
	}
	return 0;
}


void CVICALLBACK FileSelect (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	FileSelectPopup ("", "*.txt", "", "Data File", VAL_LOAD_BUTTON, 0, 1, 1, 0, FilePath);
	fp = fopen(FilePath,"rb");
	GotFile = 1;
	
}

void CVICALLBACK SelectExit (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	exit(0);
	return;
}



int CVICALLBACK ProcessRecords (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int status, i, MeterValue;
	char FirstLine[260];

	switch (event)
	{
		case EVENT_COMMIT:
			if (GotFile){
				//Process file Header
				fread(&result_time, 18,1,fp);
				sscanf(result_time, "%d%f", &blkhdr_ticks, &relativetime);
				result_time[16] = '\0';
				MessagePopup ("First File Record", result_time);
				status = fseek (fp, 0, SEEK_SET); 				//Reset to start of File
				
				//Let's get the first record
				//Check that we have an non-zero 1st record
				if (RecordOne > 0){
					SkipToRecord(RecordOne);
				}
				if (NumRecords > 0){
					i = 0;
					while (i < NumRecords){
						GetRecord(i);
						i++;
						MeterValue = ((float)i/(float)NumRecords)* 100 ;
						SetCtrlVal (PANEL, PANEL_PROCESSEDMETER, MeterValue);
						sprintf(FirstLine, "%d  %f", blkhdr_ticks, relativetime);
						FirstLine[16] = '\0';  
						if(Switch){
							status = ConfirmPopup ("Data Record Continue to Show?", FirstLine);
							if (!status){
								Switch = 0;
							}
								
						}
					}
				}
			}	
				
			break;
	}
	return 0;
}

void SkipToRecord(int Rec){
	int status;
	long NewPosition =0;
	
	 //move to start of 64 char records
	NewPosition = (Rec-1) * TOTALRECORDSIZE;
	status = fseek (fp, NewPosition, SEEK_CUR);
	return;
}

int GetRecord(int RecNum)
{
	size_t NumRead;

	NumRead = fread ((DataPointer + (RecNum)*TOTALRECORDSIZE), 18, 1, fp); //get 1st line
  
	sscanf((DataPointer + (RecNum)*TOTALRECORDSIZE), "%d%f", &blkhdr_ticks, &relativetime);
	
	NumRead = fread ((DataPointer + (RecNum)*TOTALRECORDSIZE + 18), DATARECORDSIZE, 1, fp) + NumRead;
	return (NumRead);
}

	

int CVICALLBACK ViewDataSwitch (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(panel,control, &Switch);

			break;
	}
	return 0;
}
