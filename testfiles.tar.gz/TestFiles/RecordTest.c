#include <formatio.h>
#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include <stdio.h>
#include <ansi_c.h>
#include <lowlvlio.h>
#include "RecordTest.h"

#define RECORDSIZE 1298
#define GOTFILE 0
#define FREC 1
#define NREC 2

static int panelHandle;

short NumberRecordsINFile =0,  FirstRecord =0, RecordsToRead = 0;
char PathName[260];
int FileStatus[3] = {0,0,0};				  //status of file - Selected, First Record, Number Records
int CurrentRecordPos = 0;					  //record we are positioned to read
int BytesBeforeStart = 0, ByteSpaceRequired = 0 ;
char *BufferPtr;
int FileHandle;
size_t FileSizeInBytes;
int BytePointer;


//Prototypes
void MustSelectFile(void) 	  ;
int GetRecord(int rnum, int *bytes)  ;
void GoReadRecord(int *bytes) ;
void SkipToRecord(int position)  ;
void PositionToFirstRecord(int position);


int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "RecordTest.uir", PANEL)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

int CVICALLBACK GetStartRecord (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case EVENT_COMMIT:
			if (!FileStatus[GOTFILE] )	   {
				MustSelectFile();
				return 0;
			}
			if (!FileStatus[GOTFILE] )	   {
				MustSelectFile();
				return 0;
			}
			GetCtrlVal (panelHandle, PANEL_RecordStart, &FirstRecord);
			FileStatus[FREC] =1;
			BytesBeforeStart = (FirstRecord-1) * RECORDSIZE;

			break;
	}
	return 0;
}

int CVICALLBACK GetNumRecords (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	switch (event)
	{
		case EVENT_COMMIT:
			if (!FileStatus[GOTFILE]  )	   {
					MustSelectFile();
					return 0;
			}
			GetCtrlVal (panelHandle, PANEL_NumRecRead, &RecordsToRead); 
			FileStatus[NREC] =1; 
			ByteSpaceRequired = RecordsToRead * RECORDSIZE;
			break;
	}
	return 0;
}

void CVICALLBACK SelectFile (int menuBar, int menuItem, void *callbackData,
		int panel)
{
//	ssize_t FileSizeInBytes;
	int status;
	
	status = FileSelectPopup ("", "*.txt", "", "Select A File To Process", VAL_LOAD_BUTTON, 0, 1, 1, 0, PathName);
	if (status != VAL_EXISTING_FILE_SELECTED){
		MessagePopup("Error","Must Select an Existing File");
			return;
	}
	FileHandle = OpenFile (PathName, VAL_READ_ONLY, VAL_OPEN_AS_IS, VAL_BINARY);
	CurrentRecordPos = 1;   
	status = GetFileInfo (PathName, &FileSizeInBytes);
	NumberRecordsINFile = FileSizeInBytes/RECORDSIZE;
	status = SetCtrlVal (panelHandle, PANEL_NUMBERRECS, NumberRecordsINFile);
	FileStatus[GOTFILE] = 1;
	return;
	

}

void CVICALLBACK Execute (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	int numr = 1;

	if (!(FileStatus[GOTFILE] && FileStatus[FREC] &&FileStatus[NREC]) )	   {
		MustSelectFile();
		return ;
	}
	if (( BytesBeforeStart + (ByteSpaceRequired)) > FileSizeInBytes)
	{
		MessagePopup("Error", "Attempt to Read Past End of File");
		return;
	}
	PositionToFirstRecord(FirstRecord-1); //we know it is FirstRecord
	
	BufferPtr = malloc(ByteSpaceRequired);		//Get the space
	if (BufferPtr == NULL){
		MessagePopup("ERROR", "Buffer Allocation Failed");
			return;
	}
	BytePointer = 0;	//byte position in buffer so far - used for reading
	GoReadRecord (&BytePointer);			 //get 1st
	while (numr < RecordsToRead		   ){
		GoReadRecord(&BytePointer);
		numr++;
	}

	MessagePopup("COMPLETE", "All Messages Read");
	free(BufferPtr);
	FileStatus[GOTFILE] =0;
	FileStatus[FREC] = 0;
	FileStatus[NREC] = 0;
	return;
	

}

void CVICALLBACK ExitProgram (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	QuitUserInterface (0);
}

void MustSelectFile(void)
{
	MessagePopup("Caution", "Must Select a File First");
	return ;
}


void PositionToFirstRecord(int position)
{
	if (position <= 1)
	{
		close(FileHandle);
		FileHandle = OpenFile (PathName, VAL_READ_ONLY, VAL_OPEN_AS_IS, VAL_BINARY);   
		CurrentRecordPos = 1;
		return;
	}
	else
	{
		SkipToRecord(position); //skip by reading and get to record we need   ;
		return;
	}
}
 /*
int GetRecord(int rnum, int *bytes)		   //read the recor specified in rnum
{
	if (CurrentRecord == rnum){  //positioned to read it already, so read
		GoReadRecord();
		break;
	}
	elseif (CurrentRecordPos >  rnum){   //too far, rewind and go forward to record
		close (FileHandle);
		FileHandle = OpenFile (PathName, VAL_READ_ONLY, VAL_OPEN_AS_IS, VAL_BINARY);   
		CurrentRecordPos = 1;
		while (CurrentRecordPos <= rnum){
			GoReadRecord(bytes);
		}
		break;
	}
	else {
		while (CurrentRecordPos < (rnum+1)){   //read up to and including current record
			GoReadRecord(bytes);
		}
	}// now we have the record read
	return (1);
}
*/
			
void GoReadRecord(int *bytes){
	char *bufferptr;
			//
//	bufferptr = BufferPtr   + *bytes;
	read(FileHandle, (BufferPtr   + *bytes), RECORDSIZE);
	*bytes = *bytes + RECORDSIZE;
	return ;
}
	
	
void SkipToRecord(int position)
{
	char localBuffer[RECORDSIZE];
	int recn;
	
	recn = 1;
	while (recn < position){
		read(FileHandle, localBuffer, RECORDSIZE);			  //read over same buffer
		recn++   ;
	}
}
